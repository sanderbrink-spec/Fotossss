# AI Fotograaf Pro V5 • Photos by Loes

Professionele lokale foto-app met geïntegreerde camera, galerij, batchverwerking en voor/na vergelijking.

## Ingebouwd
- CameraX live camera-preview
- Tik-to-focus
- Zoom 1x–8x
- Flitser UIT/AUTO/AAN
- Zelfontspanner 0/3/10 sec
- Regel van derden raster
- Fotomodi PRO, PORTRET, NACHT, PRODUCT, LANDSCHAP
- Galerij-import tot 100 foto's
- AI PERFECT automatische verbetering
- Belichting, contrast, kleur en detail
- Lokale gezichtsdetectie via ML Kit
- Voor/na-knop in editor
- Bewaren naar Foto's/Photos by Loes
- Volledig lokaal; geen serverupload

Dit is een professionele offline basis. Voor echte generatieve retouching/super-resolution zijn aanvullende lokale neurale modellen nodig.
