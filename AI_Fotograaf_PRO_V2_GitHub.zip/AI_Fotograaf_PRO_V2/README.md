# AI Fotograaf Pro V2

Android app for local photo enhancement.

V2 is a hybrid local pipeline: real bundled on-device ML Kit face detection plus local pixel processing for exposure, tone, white balance, denoise/detail and subtle skin retouching. Photos are processed on-device and saved locally.

This version does NOT claim generative AI, true super-resolution, or full semantic scene segmentation. Those require additional local neural models and runtime integration.
