package nl.aifotograaf.pro;

import android.app.Activity;
import android.os.Bundle;
import android.provider.MediaStore;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.android.gms.tasks.Tasks;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    static final int PICK = 42;
    Button selectButton, processButton;
    ProgressBar progress;
    TextView status, result;
    ArrayList<Uri> photos = new ArrayList<>();
    FaceDetector faceDetector;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        selectButton=findViewById(R.id.selectButton);
        processButton=findViewById(R.id.processButton);
        progress=findViewById(R.id.progress);
        status=findViewById(R.id.status);
        result=findViewById(R.id.result);

        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .build();
        faceDetector = FaceDetection.getClient(options);

        selectButton.setOnClickListener(v -> choosePhotos());
        processButton.setOnClickListener(v -> processAll());
    }

    void choosePhotos() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK);
    }

    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d);
        if(r!=PICK || c!=RESULT_OK || d==null) return;
        photos.clear();
        if(d.getClipData()!=null) {
            int n=Math.min(100,d.getClipData().getItemCount());
            for(int x=0;x<n;x++) photos.add(d.getClipData().getItemAt(x).getUri());
        } else if(d.getData()!=null) photos.add(d.getData());
        status.setText(photos.size()+" foto"+(photos.size()==1?"":"'s")+" geselecteerd");
        processButton.setEnabled(!photos.isEmpty());
        progress.setProgress(0);
    }

    void processAll() {
        processButton.setEnabled(false); selectButton.setEnabled(false);
        new Thread(() -> {
            int done=0, faces=0, failed=0;
            for(Uri u: photos) {
                try { faces += processOne(u); } catch(Exception e) { failed++; }
                done++;
                int p=(int)(done*100f/photos.size());
                final int f=faces, bad=failed;
                runOnUiThread(() -> { progress.setProgress(p); status.setText("Verwerken: "+p+"% • gezichten: "+f); });
            }
            final int f=faces, bad=failed;
            runOnUiThread(() -> {
                selectButton.setEnabled(true); processButton.setEnabled(!photos.isEmpty());
                status.setText("Klaar • "+photos.size()+" foto's verwerkt");
                result.setText("V2 voltooid. "+f+" gezichtsdetecties gebruikt"+(bad>0?" • "+bad+" foto('s) overgeslagen":"")+". Resultaten staan in Foto's/Galerij.");
            });
        }).start();
    }

    int processOne(Uri uri) throws Exception {
        Bitmap src;
        try (InputStream is=getContentResolver().openInputStream(uri)) { src=BitmapFactory.decodeStream(is); }
        if(src==null) throw new IOException("bitmap");
        int max=3500;
        float scale=Math.min(1f, max/(float)Math.max(src.getWidth(),src.getHeight()));
        int w=Math.max(1,(int)(src.getWidth()*scale));
        int h=Math.max(1,(int)(src.getHeight()*scale));
        Bitmap work=Bitmap.createScaledBitmap(src,w,h,true);
        if(work.getConfig()!=Bitmap.Config.ARGB_8888) work=work.copy(Bitmap.Config.ARGB_8888,true);

        // 1) Analyseer lokaal en maak een sterke maar natuurlijke basiscorrectie.
        autoTone(work);
        whiteBalance(work);
        denoiseAndDetail(work);

        // 2) Echte on-device ML: gezichten detecteren en alleen binnen gezichtsgebieden retoucheren.
        InputImage image=InputImage.fromBitmap(work,0);
        List<Face> detected=Tasks.await(faceDetector.process(image),30,TimeUnit.SECONDS);
        for(Face face: detected) enhanceFace(work, face.getBoundingBox());

        save(work);
        src.recycle();
        work.recycle();
        return detected.size();
    }

    void autoTone(Bitmap b) {
        int w=b.getWidth(), h=b.getHeight();
        long sum=0; int min=255,max=0,count=0;
        int step=Math.max(1,Math.min(w,h)/180);
        for(int y=0;y<h;y+=step) for(int x=0;x<w;x+=step) {
            int c=b.getPixel(x,y); int r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
            int l=(r*30+g*59+bl*11)/100; sum+=l; min=Math.min(min,l); max=Math.max(max,l); count++;
        }
        float avg=sum/(float)Math.max(1,count);
        float exposure=(128f-avg)*0.42f;
        float range=Math.max(50,max-min);
        float contrast=1.0f + Math.max(-0.04f,Math.min(0.14f,(128f-range)*0.0007f));
        int[] px=new int[w*h]; b.getPixels(px,0,w,0,0,w,h);
        for(int i=0;i<px.length;i++) {
            int c=px[i];
            int r=clamp((int)(((Color.red(c)-128)*contrast)+128+exposure));
            int g=clamp((int)(((Color.green(c)-128)*contrast)+128+exposure));
            int bl=clamp((int)(((Color.blue(c)-128)*contrast)+128+exposure));
            // compress extreme highlights slightly and lift deep shadows.
            r=tone(r); g=tone(g); bl=tone(bl);
            px[i]=Color.rgb(r,g,bl);
        }
        b.setPixels(px,0,w,0,0,w,h);
    }

    int tone(int v) {
        if(v>225) v=225+(v-225)/2;
        if(v<35) v=35+(v-35)/2;
        return clamp(v);
    }

    void whiteBalance(Bitmap b) {
        int w=b.getWidth(),h=b.getHeight(),step=Math.max(1,Math.min(w,h)/180);
        long sr=0,sg=0,sb=0,n=0;
        for(int y=0;y<h;y+=step) for(int x=0;x<w;x+=step){int c=b.getPixel(x,y);sr+=Color.red(c);sg+=Color.green(c);sb+=Color.blue(c);n++;}
        float ar=sr/(float)n, ag=sg/(float)n, ab=sb/(float)n;
        float target=(ar+ag+ab)/3f;
        float kr=1f+(target-ar)/900f, kg=1f+(target-ag)/900f, kb=1f+(target-ab)/900f;
        int[] px=new int[w*h];b.getPixels(px,0,w,0,0,w,h);
        for(int i=0;i<px.length;i++){int c=px[i];px[i]=Color.rgb(clamp((int)(Color.red(c)*kr)),clamp((int)(Color.green(c)*kg)),clamp((int)(Color.blue(c)*kb)));}
        b.setPixels(px,0,w,0,0,w,h);
    }

    void denoiseAndDetail(Bitmap b) {
        int w=b.getWidth(),h=b.getHeight();
        int[] src=new int[w*h]; b.getPixels(src,0,w,0,0,w,h); int[] out=src.clone();
        for(int y=1;y<h-1;y++) for(int x=1;x<w-1;x++) {
            int i=y*w+x,c=src[i];
            int r=0,g=0,bl=0;
            for(int dy=-1;dy<=1;dy++) for(int dx=-1;dx<=1;dx++){int q=src[(y+dy)*w+x+dx];r+=Color.red(q);g+=Color.green(q);bl+=Color.blue(q);}
            r/=9;g/=9;bl/=9;
            int rr=clamp((int)(Color.red(c)*1.12-r*0.12));
            int gg=clamp((int)(Color.green(c)*1.12-g*0.12));
            int bb=clamp((int)(Color.blue(c)*1.12-bl*0.12));
            out[i]=Color.rgb(rr,gg,bb);
        }
        b.setPixels(out,0,w,0,0,w,h);
    }

    void enhanceFace(Bitmap b, Rect face) {
        int left=Math.max(0,face.left), top=Math.max(0,face.top);
        int right=Math.min(b.getWidth()-1,face.right), bottom=Math.min(b.getHeight()-1,face.bottom);
        int fw=right-left+1, fh=bottom-top+1;
        if(fw<40||fh<40)return;
        int[] px=new int[b.getWidth()*b.getHeight()];b.getPixels(px,0,b.getWidth(),0,0,b.getWidth(),b.getHeight());
        // Subtle skin smoothing: only warm, moderately saturated skin-like pixels inside the face box.
        int[] copy=px.clone();
        for(int y=top+1;y<bottom;y++) for(int x=left+1;x<right;x++) {
            int i=y*b.getWidth()+x,c=copy[i]; float[] hsv=new float[3];Color.colorToHSV(c,hsv);
            boolean skin=hsv[0]>=5&&hsv[0]<=50&&hsv[1]>=0.10f&&hsv[1]<=0.72f&&hsv[2]>=0.20f;
            if(!skin) continue;
            int sumR=0,sumG=0,sumB=0,n=0;
            for(int dy=-1;dy<=1;dy++) for(int dx=-1;dx<=1;dx++){int q=copy[(y+dy)*b.getWidth()+x+dx];sumR+=Color.red(q);sumG+=Color.green(q);sumB+=Color.blue(q);n++;}
            int r=(int)(Color.red(c)*0.68f+(sumR/(float)n)*0.32f);
            int g=(int)(Color.green(c)*0.68f+(sumG/(float)n)*0.32f);
            int bl=(int)(Color.blue(c)*0.68f+(sumB/(float)n)*0.32f);
            // tiny complexion lift, preserving texture.
            r=clamp(r+3);g=clamp(g+2);bl=clamp(bl+1);
            px[i]=Color.rgb(r,g,bl);
        }
        b.setPixels(px,0,b.getWidth(),0,0,b.getWidth(),b.getHeight());
    }

    int clamp(int v){return Math.max(0,Math.min(255,v));}

    void save(Bitmap out) throws Exception {
        String name="AI_PRO_V2_"+System.currentTimeMillis()+".jpg";
        ContentValues v=new ContentValues();
        v.put(MediaStore.Images.Media.DISPLAY_NAME,name);
        v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
        v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/AI Fotograaf Pro V2");
        Uri dest=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
        if(dest==null) throw new IOException("save");
        try(OutputStream os=getContentResolver().openOutputStream(dest)){out.compress(Bitmap.CompressFormat.JPEG,96,os);}
    }

    @Override protected void onDestroy(){super.onDestroy();if(faceDetector!=null)faceDetector.close();}
}
