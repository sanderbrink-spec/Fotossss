package nl.aifotograaf.pro;

import android.app.Activity;
import android.os.Bundle;
import android.provider.MediaStore;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.face.FaceLandmark;
import com.google.android.gms.tasks.Tasks;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    static final int PICK = 42;
    Button selectButton, processButton;
    ProgressBar progress;
    TextView status, result;
    ArrayList<Uri> photos = new ArrayList<>();
    FaceDetector faceDetector;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        selectButton=findViewById(R.id.selectButton);
        processButton=findViewById(R.id.processButton);
        progress=findViewById(R.id.progress);
        status=findViewById(R.id.status);
        result=findViewById(R.id.result);
        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .setMinFaceSize(0.04f)
                .enableTracking()
                .build();
        faceDetector = FaceDetection.getClient(options);
        selectButton.setOnClickListener(v -> choosePhotos());
        processButton.setOnClickListener(v -> processAll());
    }

    void choosePhotos() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK);
    }

    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d); if(r!=PICK||c!=RESULT_OK||d==null)return;
        photos.clear();
        if(d.getClipData()!=null){int n=Math.min(100,d.getClipData().getItemCount());for(int x=0;x<n;x++)photos.add(d.getClipData().getItemAt(x).getUri());}
        else if(d.getData()!=null)photos.add(d.getData());
        status.setText(photos.size()+" foto's geselecteerd"); processButton.setEnabled(!photos.isEmpty()); progress.setProgress(0);
    }

    void processAll(){
        processButton.setEnabled(false); selectButton.setEnabled(false);
        new Thread(() -> {
            int done=0,faces=0,failed=0;
            for(Uri u:photos){try{faces+=processOne(u);}catch(Exception e){failed++;}done++;int p=(int)(done*100f/photos.size());final int f=faces,bad=failed;runOnUiThread(()->{progress.setProgress(p);status.setText("AI verwerken: "+p+"% • gezichten: "+f);});}
            final int f=faces,bad=failed;runOnUiThread(()->{selectButton.setEnabled(true);processButton.setEnabled(!photos.isEmpty());status.setText("Klaar • "+photos.size()+" foto's verwerkt");result.setText("V4 voltooid • "+f+" gezichten gedetecteerd"+(bad>0?" • "+bad+" mislukt":"")+". Resultaten in Foto's/Galerij.");});
        }).start();
    }

    int processOne(Uri uri)throws Exception{
        Bitmap src;
        try(InputStream is=getContentResolver().openInputStream(uri)){src=BitmapFactory.decodeStream(is);}
        if(src==null)throw new IOException("Kan foto niet lezen");
        int max=2600;float scale=Math.min(1f,max/(float)Math.max(src.getWidth(),src.getHeight()));
        int w=Math.max(1,(int)(src.getWidth()*scale)),h=Math.max(1,(int)(src.getHeight()*scale));
        Bitmap work=Bitmap.createScaledBitmap(src,w,h,true).copy(Bitmap.Config.ARGB_8888,true);
        AutoStats stats=analyze(work);
        proTone(work,stats);
        localContrast(work);
        colorBalance(work);
        detail(work);
        InputImage image=InputImage.fromBitmap(work,0);
        List<Face> detected=Tasks.await(faceDetector.process(image),30,TimeUnit.SECONDS);
        for(Face face:detected) enhanceFace(work,face);
        save(work);
        src.recycle();work.recycle();return detected.size();
    }

    static class AutoStats{float avg,p05,p50,p95;}
    AutoStats analyze(Bitmap b){
        int w=b.getWidth(),h=b.getHeight(),step=Math.max(1,Math.min(w,h)/160),n=0;int[] hist=new int[256];long sum=0;
        for(int y=0;y<h;y+=step)for(int x=0;x<w;x+=step){int c=b.getPixel(x,y);int l=(30*Color.red(c)+59*Color.green(c)+11*Color.blue(c))/100;hist[l]++;sum+=l;n++;}
        AutoStats s=new AutoStats();s.avg=sum/(float)Math.max(1,n);int a=0;for(int i=0;i<256;i++){a+=hist[i];if(a>=n*.05){s.p05=i;break;}}a=0;for(int i=0;i<256;i++){a+=hist[i];if(a>=n*.50){s.p50=i;break;}}a=0;for(int i=0;i<256;i++){a+=hist[i];if(a>=n*.95){s.p95=i;break;}}return s;
    }

    void proTone(Bitmap b,AutoStats s){
        int w=b.getWidth(),h=b.getHeight();int[] px=new int[w*h];b.getPixels(px,0,w,0,0,w,h);
        float exposure=(128-s.p50)*0.48f;float range=Math.max(40,s.p95-s.p05);float contrast=1.0f+Math.min(.18f,Math.max(-.05f,(110-range)*.0012f));
        for(int i=0;i<px.length;i++){int c=px[i];int r=tone((int)((Color.red(c)-128)*contrast+128+exposure));int g=tone((int)((Color.green(c)-128)*contrast+128+exposure));int bl=tone((int)((Color.blue(c)-128)*contrast+128+exposure));float lum=(r*.3f+g*.59f+bl*.11f)/255f;float sat=1f+(lum<.22f?.05f:lum>.86f?-.04f:.025f);float gray=(r+g+bl)/3f;r=clamp((int)(gray+(r-gray)*sat));g=clamp((int)(gray+(g-gray)*sat));bl=clamp((int)(gray+(bl-gray)*sat));px[i]=Color.rgb(r,g,bl);}b.setPixels(px,0,w,0,0,w,h);
    }

    void localContrast(Bitmap b){
        int w=b.getWidth(),h=b.getHeight();int[] src=new int[w*h];b.getPixels(src,0,w,0,0,w,h);int[] out=src.clone();
        for(int y=2;y<h-2;y++)for(int x=2;x<w-2;x++){int i=y*w+x,c=src[i];int l=lum(c);int n=0;for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++)n+=lum(src[(y+dy)*w+x+dx]);float avg=n/25f;float k=.16f;int r=clamp((int)(Color.red(c)+(l-avg)*k));int g=clamp((int)(Color.green(c)+(l-avg)*k));int bl=clamp((int)(Color.blue(c)+(l-avg)*k));out[i]=Color.rgb(r,g,bl);}b.setPixels(out,0,w,0,0,w,h);
    }

    int lum(int c){return (30*Color.red(c)+59*Color.green(c)+11*Color.blue(c))/100;}

    void colorBalance(Bitmap b){int w=b.getWidth(),h=b.getHeight(),step=Math.max(1,Math.min(w,h)/140);long r=0,g=0,bl=0,n=0;for(int y=0;y<h;y+=step)for(int x=0;x<w;x+=step){int c=b.getPixel(x,y);r+=Color.red(c);g+=Color.green(c);bl+=Color.blue(c);n++;}float ar=r/(float)n,ag=g/(float)n,ab=bl/(float)n,t=(ar+ag+ab)/3f;float kr=1+(t-ar)/1200f,kg=1+(t-ag)/1200f,kb=1+(t-ab)/1200f;int[] px=new int[w*h];b.getPixels(px,0,w,0,0,w,h);for(int i=0;i<px.length;i++){int c=px[i];px[i]=Color.rgb(clamp((int)(Color.red(c)*kr)),clamp((int)(Color.green(c)*kg)),clamp((int)(Color.blue(c)*kb)));}b.setPixels(px,0,w,0,0,w,h);}

    void detail(Bitmap b){int w=b.getWidth(),h=b.getHeight();int[] src=new int[w*h];b.getPixels(src,0,w,0,0,w,h);int[] out=src.clone();for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=y*w+x,c=src[i];int avg=(lum(src[i-1])+lum(src[i+1])+lum(src[i-w])+lum(src[i+w]))/4;int d=lum(c)-avg;float k=.22f;out[i]=Color.rgb(clamp((int)(Color.red(c)+d*k)),clamp((int)(Color.green(c)+d*k)),clamp((int)(Color.blue(c)+d*k)));}b.setPixels(out,0,w,0,0,w,h);}

    void enhanceFace(Bitmap b,Face face){
        Rect box=face.getBoundingBox();int l=Math.max(0,box.left),t=Math.max(0,box.top),r=Math.min(b.getWidth()-1,box.right),bt=Math.min(b.getHeight()-1,box.bottom);if(r-l<30||bt-t<30)return;
        int w=b.getWidth(),h=b.getHeight();int[] px=new int[w*h];b.getPixels(px,0,w,0,0,w,h);int[] cp=px.clone();
        for(int y=t+1;y<bt;y++)for(int x=l+1;x<r;x++){int i=y*w+x,c=cp[i];float[] hsv=new float[3];Color.colorToHSV(c,hsv);boolean skin=(hsv[0]<55||hsv[0]>330)&&hsv[1]>.08f&&hsv[1]<.75f&&hsv[2]>.18f;if(!skin)continue;int rr=0,gg=0,bb=0,n=0;for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){int q=cp[(y+dy)*w+x+dx];rr+=Color.red(q);gg+=Color.green(q);bb+=Color.blue(q);n++;}px[i]=Color.rgb(clamp((int)(Color.red(c)*.76f+rr/(float)n*.24f+2)),clamp((int)(Color.green(c)*.76f+gg/(float)n*.24f+1)),clamp((int)(Color.blue(c)*.76f+bb/(float)n*.24f)));}
        // Brighten eyes when ML Kit landmarks are available.
        brightenLandmark(b,px,face.getLandmark(FaceLandmark.LEFT_EYE),w,h);
        brightenLandmark(b,px,face.getLandmark(FaceLandmark.RIGHT_EYE),w,h);
        brightenLandmark(b,px,face.getLandmark(FaceLandmark.MOUTH_LEFT),w,h);
        brightenLandmark(b,px,face.getLandmark(FaceLandmark.MOUTH_RIGHT),w,h);
        b.setPixels(px,0,w,0,0,w,h);
    }

    void brightenLandmark(Bitmap b,int[] px,FaceLandmark lm,int w,int h){if(lm==null)return;PointF p=lm.getPosition();int cx=(int)p.x,cy=(int)p.y,rad=Math.max(8,Math.min(w,h)/90);for(int y=Math.max(0,cy-rad);y<Math.min(h,cy+rad);y++)for(int x=Math.max(0,cx-rad);x<Math.min(w,cx+rad);x++){float d=(float)Math.hypot(x-cx,y-cy)/rad;if(d>1)continue;int i=y*w+x,c=px[i];int add=(int)(7*(1-d));px[i]=Color.rgb(clamp(Color.red(c)+add),clamp(Color.green(c)+add),clamp(Color.blue(c)+add));}}

    int tone(int v){if(v>235)v=235+(v-235)/3;if(v<25)v=25+(v-25)/2;return clamp(v);}int clamp(int v){return Math.max(0,Math.min(255,v));}

    void save(Bitmap out)throws Exception{String name="AI_PRO_V3_"+System.currentTimeMillis()+".jpg";ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/AI Fotograaf Pro V3");Uri dest=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(dest==null)throw new IOException("save");try(OutputStream os=getContentResolver().openOutputStream(dest)){out.compress(Bitmap.CompressFormat.JPEG,97,os);}}
    @Override protected void onDestroy(){super.onDestroy();if(faceDetector!=null)faceDetector.close();}
}
