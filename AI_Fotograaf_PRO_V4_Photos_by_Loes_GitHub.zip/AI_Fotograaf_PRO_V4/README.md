# AI Fotograaf Pro V4 • Photos by Loes

Premium black/gold UI with the supplied AI Fotograaf Pro / AI by Loes logo as in-app branding and launcher icon.

V4 keeps the V3 local processing pipeline and adds the new visual identity. Photos remain on-device.

Build: Gradle 8.9, Java 17, Android SDK 35.
