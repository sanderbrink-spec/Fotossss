package nl.aifotograaf.pro;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;

import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.*;
import com.google.android.gms.tasks.Tasks;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final int PICK=51, CAMERA=52;
    final int GOLD=Color.rgb(220,174,95), CREAM=Color.rgb(250,242,225), MUTED=Color.rgb(178,164,143), BG=Color.rgb(5,5,5), PANEL=Color.rgb(22,19,16);
    FrameLayout root, cameraFrame, editorFrame;
    PreviewView preview;
    ImageCapture imageCapture;
    ProcessCameraProvider cameraProvider;
    TextView status, modeText;
    Button shutter, galleryBtn, perfectBtn, compareBtn, saveBtn, backBtn;
    ImageView editorImage;
    Bitmap original, edited;
    boolean showingBefore=false;
    boolean aiMode=false;
    int timerSec=0;
    float zoom=1f;
    String mode="PRO";
    SeekBar exposureBar, contrastBar, colorBar, detailBar;
    FaceDetector detector;
    ArrayList<Uri> batch=new ArrayList<>();

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG); buildCameraUI(); setupDetector(); if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},CAMERA); else startCamera();}

    TextView tv(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(14,8,14,8);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTextColor(CREAM);b.setAllCaps(false);b.setBackground(round(PANEL,18));return b;}
    GradientDrawable round(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);g.setStroke(1,Color.rgb(75,61,45));return g;}

    void buildCameraUI(){
        root=new FrameLayout(this);root.setBackgroundColor(BG);setContentView(root);
        cameraFrame=new FrameLayout(this);root.addView(cameraFrame,new FrameLayout.LayoutParams(-1,-1));
        preview=new PreviewView(this);preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);cameraFrame.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        GridOverlay grid=new GridOverlay(this);grid.setVisibility(View.GONE);cameraFrame.addView(grid,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.VERTICAL);top.setPadding(16,12,16,0);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,150,Gravity.TOP);cameraFrame.addView(top,tp);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.logo_photos_by_loes);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);top.addView(logo,new LinearLayout.LayoutParams(-1,95));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER);modeText=tv("PRO",14,GOLD);bar.addView(modeText,new LinearLayout.LayoutParams(0,48,1));Button flash=btn("⚡ AUTO");bar.addView(flash,new LinearLayout.LayoutParams(0,48,1));Button timer=btn("⏱ 0s");bar.addView(timer,new LinearLayout.LayoutParams(0,48,1));Button gridBtn=btn("▦");bar.addView(gridBtn,new LinearLayout.LayoutParams(0,48,1));top.addView(bar);
        LinearLayout modes=new LinearLayout(this);modes.setGravity(Gravity.CENTER);String[] ms={"PRO","PORTRET","NACHT","PRODUCT","LANDSCHAP"};for(String m:ms){Button x=btn(m);x.setOnClickListener(v->{mode=m;modeText.setText(m);});modes.addView(x,new LinearLayout.LayoutParams(0,44,1));}FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-1,50,Gravity.TOP);mp.topMargin=155;cameraFrame.addView(modes,mp);
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);controls.setPadding(18,8,18,18);GradientDrawable bottom=round(Color.argb(235,8,8,8),28);controls.setBackground(bottom);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,235,Gravity.BOTTOM);bp.setMargins(12,0,12,12);cameraFrame.addView(controls,bp);
        LinearLayout tool=new LinearLayout(this);tool.setGravity(Gravity.CENTER);galleryBtn=btn("GALERIJ");tool.addView(galleryBtn,new LinearLayout.LayoutParams(0,52,1));Button zoomMinus=btn("−");tool.addView(zoomMinus,new LinearLayout.LayoutParams(0,52,1));shutter=new Button(this);shutter.setText("●");shutter.setTextSize(38);shutter.setTextColor(CREAM);shutter.setBackground(round(GOLD,80));tool.addView(shutter,new LinearLayout.LayoutParams(86,70));Button zoomPlus=btn("+");tool.addView(zoomPlus,new LinearLayout.LayoutParams(0,52,1));Button flip=btn("↻");tool.addView(flip,new LinearLayout.LayoutParams(0,52,1));controls.addView(tool);
        TextView hint=tv("Tik op beeld om scherp te stellen • zoom • flits • timer • raster",12,MUTED);hint.setGravity(Gravity.CENTER);controls.addView(hint,new LinearLayout.LayoutParams(-1,40));
        shutter.setOnClickListener(v->capture());galleryBtn.setOnClickListener(v->choosePhotos());zoomPlus.setOnClickListener(v->setZoom(Math.min(8f,zoom+.5f)));zoomMinus.setOnClickListener(v->setZoom(Math.max(1f,zoom-.5f)));gridBtn.setOnClickListener(v->grid.setVisibility(grid.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
        timer.setOnClickListener(v->{timerSec=timerSec==0?3:timerSec==3?10:0;timer.setText("⏱ "+timerSec+"s");});flash.setOnClickListener(v->{if(imageCapture!=null){int f=imageCapture.getFlashMode();int n=f==ImageCapture.FLASH_MODE_OFF?ImageCapture.FLASH_MODE_AUTO:f==ImageCapture.FLASH_MODE_AUTO?ImageCapture.FLASH_MODE_ON:ImageCapture.FLASH_MODE_OFF;imageCapture.setFlashMode(n);flash.setText(n==0?"⚡ UIT":n==1?"⚡ AUTO":"⚡ AAN");}});
        preview.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_UP&&cameraProvider!=null){try{MeteringPointFactory f=preview.getMeteringPointFactory();FocusMeteringAction a=new FocusMeteringAction.Builder(f.createPoint(e.getX(),e.getY())).build();Camera cam=preview.getTag() instanceof Camera?(Camera)preview.getTag():null;if(cam!=null)cam.getCameraControl().startFocusAndMetering(a);}catch(Exception ignored){}}return true;});
    }

    void startCamera(){ListenableFuture<ProcessCameraProvider> f=ProcessCameraProvider.getInstance(this);f.addListener(()->{try{cameraProvider=f.get();bindCamera();}catch(Exception e){toast("Camera kon niet starten");}},ContextCompat.getMainExecutor(this));}
    void bindCamera(){if(cameraProvider==null)return;Preview p=new Preview.Builder().build();imageCapture=new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).setJpegQuality(97).build();CameraSelector sel=CameraSelector.DEFAULT_BACK_CAMERA;cameraProvider.unbindAll();Camera cam=cameraProvider.bindToLifecycle(this,sel,p,imageCapture);preview.setTag(cam);p.setSurfaceProvider(preview.getSurfaceProvider());cam.getCameraControl().setZoomRatio(1f);}
    void setZoom(float z){zoom=z;Object o=preview.getTag();if(o instanceof Camera)((Camera)o).getCameraControl().setZoomRatio(z);}
    void capture(){if(imageCapture==null)return;Runnable r=()->{File f=new File(getCacheDir(),"capture_"+System.currentTimeMillis()+".jpg");ImageCapture.OutputFileOptions o=new ImageCapture.OutputFileOptions.Builder(f).build();imageCapture.takePicture(o,ContextCompat.getMainExecutor(this),new ImageCapture.OnImageSavedCallback(){public void onImageSaved(ImageCapture.OutputFileResults x){try{original=BitmapFactory.decodeFile(f.getAbsolutePath());showEditor();}catch(Exception e){toast("Foto kon niet worden geladen");}}public void onError(ImageCaptureException e){toast("Foto maken mislukt");}});};if(timerSec>0){shutter.setEnabled(false);new Handler().postDelayed(()->{r.run();shutter.setEnabled(true);},timerSec*1000L);}else r.run();}

    void choosePhotos(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=PICK||c!=RESULT_OK||d==null)return;batch.clear();if(d.getClipData()!=null){for(int i=0;i<Math.min(100,d.getClipData().getItemCount());i++)batch.add(d.getClipData().getItemAt(i).getUri());}else if(d.getData()!=null)batch.add(d.getData());if(batch.size()==1){try{original=read(batch.get(0));showEditor();}catch(Exception e){toast("Foto kon niet worden geopend");}}else processBatch();}
    Bitmap read(Uri u)throws Exception{try(InputStream is=getContentResolver().openInputStream(u)){Bitmap b=BitmapFactory.decodeStream(is);if(b==null)throw new IOException();return b;}}

    void setupDetector(){FaceDetectorOptions o=new FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL).setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).setMinFaceSize(.03f).build();detector=FaceDetection.getClient(o);}

    void showEditor(){cameraFrame.setVisibility(View.GONE);buildEditor();editorFrame.setVisibility(View.VISIBLE);applyEdit();}
    void buildEditor(){if(editorFrame!=null)root.removeView(editorFrame);editorFrame=new FrameLayout(this);editorFrame.setBackgroundColor(BG);root.addView(editorFrame,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(8,10,8,4);Button back=btn("‹ CAMERA");top.addView(back,new LinearLayout.LayoutParams(105,52));TextView title=tv("PHOTOS BY LOES",16,GOLD);title.setGravity(Gravity.CENTER);top.addView(title,new LinearLayout.LayoutParams(0,52,1));compareBtn=btn("VOOR / NA");top.addView(compareBtn,new LinearLayout.LayoutParams(110,52));editorFrame.addView(top,new FrameLayout.LayoutParams(-1,66,Gravity.TOP));backBtn=back;back.setOnClickListener(v->{editorFrame.setVisibility(View.GONE);cameraFrame.setVisibility(View.VISIBLE);});compareBtn.setOnClickListener(v->{showingBefore=!showingBefore;editorImage.setImageBitmap(showingBefore?original:edited);compareBtn.setText(showingBefore?"NA TONEN":"VOOR / NA");});
        editorImage=new ImageView(this);editorImage.setScaleType(ImageView.ScaleType.FIT_CENTER);FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,0);ip.topMargin=70;ip.bottomMargin=350;editorFrame.addView(editorImage,ip);
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(18,8,18,14);panel.setBackground(round(Color.rgb(15,13,11),28));FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(-1,350,Gravity.BOTTOM);pp.setMargins(10,0,10,10);editorFrame.addView(panel,pp);
        LinearLayout buttons=new LinearLayout(this);perfectBtn=btn("✦ AI PERFECT");saveBtn=btn("OPSLAAN");buttons.addView(perfectBtn,new LinearLayout.LayoutParams(0,52,1));buttons.addView(saveBtn,new LinearLayout.LayoutParams(0,52,1));panel.addView(buttons);
        exposureBar=addSlider(panel,"BELICHTING",-100,100,0);contrastBar=addSlider(panel,"CONTRAST",-100,100,0);colorBar=addSlider(panel,"KLEUR",-100,100,0);detailBar=addSlider(panel,"DETAIL",0,100,40);
        perfectBtn.setOnClickListener(v->{aiMode=true;exposureBar.setProgress(50);contrastBar.setProgress(60);colorBar.setProgress(55);detailBar.setProgress(72);applyEdit();});saveBtn.setOnClickListener(v->saveEdited());
    }
    SeekBar addSlider(LinearLayout p,String label,int min,int max,int value){TextView l=tv(label+"  "+value,11,MUTED);p.addView(l,new LinearLayout.LayoutParams(-1,24));SeekBar s=new SeekBar(this);s.setMax(max-min);s.setProgress(value-min);s.setTag(label);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int x,boolean f){l.setText(label+"  "+(x+min));if(f)applyEdit();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});p.addView(s,new LinearLayout.LayoutParams(-1,34));return s;}

    void applyEdit(){if(original==null)return;new Thread(()->{try{Bitmap base=scale(original,1400);float exp=(exposureBar.getProgress()-100)/100f;float con=(contrastBar.getProgress()-100)/100f;float sat=(colorBar.getProgress()-100)/100f;float detail=detailBar.getProgress()/100f;Bitmap out=enhance(base,exp,con,sat,detail);
            if(aiMode && detector!=null){try{InputImage ii=InputImage.fromBitmap(out,0);java.util.List<Face> fs=Tasks.await(detector.process(ii),15,TimeUnit.SECONDS);for(Face f:fs) facePolish(out,f);}catch(Exception ignored){}}
            edited=out;runOnUiThread(()->{if(!showingBefore)editorImage.setImageBitmap(edited);});}catch(Exception ignored){}}).start();}
    Bitmap scale(Bitmap b,int max){float sc=Math.min(1f,max/(float)Math.max(b.getWidth(),b.getHeight()));if(sc>=.999f)return b.copy(Bitmap.Config.ARGB_8888,true);return Bitmap.createScaledBitmap(b,Math.max(1,(int)(b.getWidth()*sc)),Math.max(1,(int)(b.getHeight()*sc)),true).copy(Bitmap.Config.ARGB_8888,true);}
    Bitmap enhance(Bitmap src,float exp,float con,float sat,float detail){Bitmap b=src.copy(Bitmap.Config.ARGB_8888,true);int w=b.getWidth(),h=b.getHeight();int[] p=new int[w*h];b.getPixels(p,0,w,0,0,w,h);float gain=1f+exp*.55f;float c=1f+con*.32f;float s=1f+sat*.28f;for(int i=0;i<p.length;i++){int q=p[i];float r=Color.red(q)*gain,g=Color.green(q)*gain,bl=Color.blue(q)*gain;float gray=(r+g+bl)/3f;r=gray+(r-gray)*s;g=gray+(g-gray)*s;bl=gray+(bl-gray)*s;r=(r-128)*c+128;g=(g-128)*c+128;bl=(bl-128)*c+128;p[i]=Color.rgb(clamp((int)r),clamp((int)g),clamp((int)bl));}b.setPixels(p,0,w,0,0,w,h);if(detail>.1f)sharpen(b,.05f+.22f*detail);return b;}
    void facePolish(Bitmap b,Face face){
        Rect q=face.getBoundingBox();int l=Math.max(0,q.left),t=Math.max(0,q.top),r=Math.min(b.getWidth()-1,q.right),bt=Math.min(b.getHeight()-1,q.bottom);
        if(r-l<24||bt-t<24)return;
        int w=b.getWidth(),h=b.getHeight();int[] px=new int[w*h];b.getPixels(px,0,w,0,0,w,h);int[] cp=px.clone();
        for(int y=t;y<bt;y++)for(int x=l;x<r;x++){int i=y*w+x,c=cp[i];float[] hsv=new float[3];Color.colorToHSV(c,hsv);boolean skin=(hsv[0]<58||hsv[0]>325)&&hsv[1]>.06f&&hsv[1]<.78f&&hsv[2]>.20f;if(!skin)continue;
            int rr=0,gg=0,bb=0,n=0;for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){int xx=Math.max(l,Math.min(r,x+dx)),yy=Math.max(t,Math.min(bt,y+dy));int z=cp[yy*w+xx];rr+=Color.red(z);gg+=Color.green(z);bb+=Color.blue(z);n++;}
            px[i]=Color.rgb(clamp((int)(Color.red(c)*.82f+rr/(float)n*.18f+1)),clamp((int)(Color.green(c)*.82f+gg/(float)n*.18f+1)),clamp((int)(Color.blue(c)*.82f+bb/(float)n*.18f)));
        }
        brighten(px,face.getLandmark(FaceLandmark.LEFT_EYE),w,h);brighten(px,face.getLandmark(FaceLandmark.RIGHT_EYE),w,h);
        b.setPixels(px,0,w,0,0,w,h);
    }
    void brighten(int[] px,FaceLandmark lm,int w,int h){if(lm==null)return;PointF p=lm.getPosition();int cx=(int)p.x,cy=(int)p.y,rad=Math.max(5,Math.min(w,h)/110);for(int y=Math.max(0,cy-rad);y<Math.min(h,cy+rad);y++)for(int x=Math.max(0,cx-rad);x<Math.min(w,cx+rad);x++){float d=(float)Math.hypot(x-cx,y-cy)/rad;if(d>1)continue;int i=y*w+x,c=px[i],a=(int)(5*(1-d));px[i]=Color.rgb(clamp(Color.red(c)+a),clamp(Color.green(c)+a),clamp(Color.blue(c)+a));}}
    void sharpen(Bitmap b,float k){int w=b.getWidth(),h=b.getHeight();int[] s=new int[w*h];b.getPixels(s,0,w,0,0,w,h);int[] o=s.clone();for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=y*w+x,c=s[i];int avg=(lum(s[i-1])+lum(s[i+1])+lum(s[i-w])+lum(s[i+w]))/4;int d=lum(c)-avg;o[i]=Color.rgb(clamp((int)(Color.red(c)+d*k)),clamp((int)(Color.green(c)+d*k)),clamp((int)(Color.blue(c)+d*k)));}b.setPixels(o,0,w,0,0,w,h);}
    int lum(int c){return (30*Color.red(c)+59*Color.green(c)+11*Color.blue(c))/100;}int clamp(int v){return Math.max(0,Math.min(255,v));}

    void processBatch(){final int total=batch.size();cameraFrame.setVisibility(View.GONE);LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(30,40,30,30);p.setGravity(Gravity.CENTER);p.setBackgroundColor(BG);TextView t=tv("AI PERFECT",28,GOLD);t.setGravity(Gravity.CENTER);p.addView(t,new LinearLayout.LayoutParams(-1,80));ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(total);p.addView(bar,new LinearLayout.LayoutParams(-1,24));TextView s=tv("0 / "+total+" foto's",16,CREAM);s.setGravity(Gravity.CENTER);p.addView(s,new LinearLayout.LayoutParams(-1,60));root.removeAllViews();root.addView(p);new Thread(()->{int done=0;for(Uri u:batch){try{Bitmap src=scale(read(u),2400);Bitmap out=enhance(src,.10f,.18f,.10f,.65f);save(out);src.recycle();}catch(Exception ignored){}done++;int d=done;runOnUiThread(()->{bar.setProgress(d);s.setText(d+" / "+total+" foto's verwerkt");});}runOnUiThread(()->{s.setText("Klaar • "+total+" foto's opgeslagen");});}).start();}
    void saveEdited(){if(edited==null)return;new Thread(()->{try{save(scale(edited,3000));runOnUiThread(()->toast("Opgeslagen in Foto's"));}catch(Exception e){runOnUiThread(()->toast("Opslaan mislukt"));}}).start();}
    void save(Bitmap out)throws Exception{String name="Photos_by_Loes_AI_"+System.currentTimeMillis()+".jpg";ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Photos by Loes");Uri d=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(d==null)throw new IOException();try(OutputStream os=getContentResolver().openOutputStream(d)){out.compress(Bitmap.CompressFormat.JPEG,97,os);}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==CAMERA&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startCamera();}
    @Override protected void onDestroy(){super.onDestroy();if(detector!=null)detector.close();}

    class GridOverlay extends View{Paint p=new Paint();GridOverlay(Context c){super(c);p.setColor(Color.argb(120,255,255,255));p.setStrokeWidth(1);setBackgroundColor(Color.TRANSPARENT);}protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();c.drawLine(w/3,0,w/3,h,p);c.drawLine(2*w/3,0,2*w/3,h,p);c.drawLine(0,h/3,w,h/3,p);c.drawLine(0,2*h/3,w,2*h/3,p);}}
}
